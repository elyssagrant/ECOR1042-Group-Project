# ECOR 1042 Lab 6 - Individual submission for batch_UI

# Update "" with your name (e.g., Cristina Ruiz Martin)
__author__ = "Josh Elsasser"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101272449"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-83"

#==========================================#
# Place your script for your batch_UI after this line

from load_data import load_data
from load_data import add_average
from sort import sort_by_key
from curve_fit import curve_fit
from histogram import histogram

file = input(
    "Please enter the name of the file where your commands are stored: ")

batch_file = open(file, 'r')

for line in batch_file:
    line = line.strip().split(";")

    if line[0] == "L":
        if line[2] == "School":
            unsorted = load_data(line[1], (line[2], line[3]))
            unsorted = add_average(unsorted)
            print("Data loaded")
        else:
            unsorted = load_data(line[1], (line[2], int(line[3])))
            unsorted = add_average(unsorted)
            print("Data loaded")

    elif line[0] == "S":
        sort = sort_by_key(unsorted, line[2], line[1])
        if line[3] == "Y":
            print("Data sorted")
            print(sort)
        else:
            print("Data sorted")

    elif line[0] == "C":
        curve = curve_fit(sort, line[1], int(line[2]))
        print(curve)

    elif line[0] == "H":
        hist = histogram(sort, line[1])
        print(hist)


batch_file.close()
