# ECOR 1042 Lab 5 - Team submission
# Remember to include docstring and type annotations for your functions

# Update "" to list all students contributing to the team work
__author__ = "Josh Elasser, Elyssa Grant, Kaeler Howk, Lucas Macdonald"

# Update "" with your team (e.g. T102)
__team__ = "T83"

#==========================================#
# Place your sort_students_age_bubble function after this line


def sort_students_age_bubble(List: list, order: str) -> list:
    """ Returns the list sorted by the entries for age given the list and a string

    Preconditions: List is type list and order is type str

    Examples:
    >>>sort_students_age_bubble([{"Age":10,"School":"GP"},{"Age":19,"School":"MS"}], "D")
    [{'Age': 19, 'School': 'MS'}, {'Age': 10, 'School': 'GP'}]

    >>>sort_students_age_bubble([{"Age":10,"School":"GP"},{"Age":19,"School":"MS"}], "D")
    [{'Age': 10, 'School': 'GP'}, {'Age': 19, 'School': 'MS'}]

    >>>sort_students_age_bubble([{"School":"GP"},{"School":"MS"}], "A")
    "Age" key is not present.
    """
    if 'Age' not in List[1].keys():
        print('"Age" key is not present.')
        return List
    elif order == "A":
        swap = True
        while swap:
            swap = False
            for i in range(len(List) - 1):
                if List[i]['Age'] > List[i + 1]['Age']:
                    aux = List[i]
                    List[i] = List[i + 1]
                    List[i + 1] = aux
                    swap = True
        return List

    elif order == "D":
        swap = True
        while swap:
            swap = False
            for i in range(len(List) - 1):
                if List[i]['Age'] < List[i + 1]['Age']:
                    aux = List[i]
                    List[i] = List[i + 1]
                    List[i + 1] = aux
                    swap = True
        return List

#==========================================#
# Place your sort_students_time_selection function after this line


def sort_students_time_selection(list_of_dict: list[dict], order: str) -> list[dict]:
    """Given a list of dictionaries with "StudyTime" as a key in the dictionary, the function will return the sorted list in ascending or descinding order given A or D.  If "StudyTime" is not a key in the dictionary, the function prints a message stating the key is not in the dictionary and returns the original list.

    Preconditions: list_of_dict is a list of at least 1 dictionary, order must be "A" or "D".

    >>> sort_students_time_selection([{"StudyTime": 12}, {"StudyTime": 11}], "A")
    [{"StudyTime": 11}, {"StudyTime": 12}]
    >>> sort_students_time_selection([{"Carl": 12}], "D")
    "StudyTime is not present"
    [{"Carl": 12}]
    >>> sort_students_time_selection([{"StudyTime": 4, "School": 9}, {"StudyTime": 11, "School": 3}, {"StudyTime": 4.9, "School": 9}, {"StudyTime": 6, "School": 9}, {"StudyTime": 9, "School": 7}], "D")
    [{"StudyTime": 11, "School": 3}, {"StudyTime": 9, "School": 7}, {"StudyTime": 6, "School": 9}, {"StudyTime": 4, "School": 9}]
    """
    studytime_in_dict = False
    studytime_list = []
    for dictionaries in list_of_dict:

        if "StudyTime" in dictionaries:
            studytime_in_dict = True
            studytime_list += [dictionaries["StudyTime"]]

    if studytime_in_dict == True:
        if order == 'A':
            for i in range(len(studytime_list)):
                min_idx = i
                for j in range(i + 1, len(studytime_list)):
                    if studytime_list[min_idx] > studytime_list[j]:
                        min_idx = j

                studytime_list[i], studytime_list[min_idx] = studytime_list[min_idx], studytime_list[i]

                list_of_dict[i], list_of_dict[min_idx] = list_of_dict[min_idx], list_of_dict[i]

        elif order == 'D':
            for i in range(len(studytime_list)):
                min_idx = i
                for j in range(i + 1, len(studytime_list)):
                    if studytime_list[min_idx] < studytime_list[j]:
                        min_idx = j

                studytime_list[i], studytime_list[min_idx] = studytime_list[min_idx], studytime_list[i]

                list_of_dict[i], list_of_dict[min_idx] = list_of_dict[min_idx], list_of_dict[i]
    else:
        print('"StudyTime" is not in the list:')
        return list_of_dict

    return list_of_dict


#==========================================#
# Place your sort_students_g_avg_insertion function after this line
def sort_students_g_avg_insertion(dict_list: list[dict], asc_desc: str):
    """
    Given a list of dictionaries and a string saying whether they are to be sorted in ascending or descending order, sorts the dictionaries according to the G_Avg key value

    Preconditions: asc_desc is "A" or "D", list contains at least one dictionary

    Examples:

    >>>sort_students_g_avg_insertion( [{"G_Avg":7.2,"School":"GP"}, {"G_Avg":9.1,"School":"MS"}], "D")
    [{"G_Avg": 9.1, "School":"MS"}, {"G_Avg":7.2, "School":"GP"}]

    >>> sort_students_g_avg_insertion([{"School":"GP"},{"School":"MS"}], "D")
    "G_Avg" key is not present
    [{"School":"GP"},{"School":"MS"}]

    >>> sort_students_g_avg_insertion([{"School":"GP", 'G_Avg': 9.5},{"School":"MS", 'G_Avg': 5.5}, {"School":"MB", 'G_Avg': 6.7}], "A")
    [{"School":"MS", 'G_Avg': 5.5}, {"School":"MB", 'G_Avg': 6.7}, {"School":"GP", 'G_Avg': 9.5}]
    """

    if "G_Avg" not in dict_list[0].keys():
        print('"G_Avg" key is not present')

        return dict_list

    if asc_desc == "A":

        for i in range(1, len(dict_list)):

            if "G_Avg" in (dict_list[i]).keys():

                key = dict_list[i]

                j = i - 1

                while j >= 0 and key['G_Avg'] < dict_list[j]['G_Avg']:

                    dict_list[j + 1] = dict_list[j]

                    j -= 1

                dict_list[j + 1] = key

    else:
        for i in range(1, len(dict_list)):

            if "G_Avg" in (dict_list[i]).keys():

                key = dict_list[i]

                j = i - 1

                while j >= 0 and key['G_Avg'] > dict_list[j]['G_Avg']:

                    dict_list[j + 1] = dict_list[j]

                    j -= 1

                dict_list[j + 1] = key

    return dict_list

#==========================================#
# Place your sort_students_failures_bubble function after this line


def sort_students_failures_bubble(list_of_dict: list[dict], order: str) -> list:
    """ Returns sorted list of dictionaries using bubble sort method using 'Failures' as key, in either ascending or descending order depending on second parameter 'order'.  If inputted a list of dictionaries then 'A' the list is sorted in ascending order, if inputted 'D' then it returns in descending order.  If key 'Failures' is not in list of dictionaries prints: "Failures" key is not present.  followed by the input: list_of_dict  on the next line


    Precondition:  list_of_dict is a list containing at least one dictionary, order is string with only string inputs being 'A' or 'D'

    >>> sort_students_failures_bubble([{"Failures":11,"School":"GP"},{"Failures":18,"School":"MS"}], "D")
    [{'Failures': 18, 'School': 'MS'}, {'Failures': 11, 'School': 'GP'}]

    >>> sort_students_failures_bubble([{"School":"GP"}, {"School":"LD"}], "A")
    "Failures" key is not present.
    [{'School':'GP'}, {'School':'LD'}]

    >>> sort_students_failures_bubble([{"Failures":11,"School":"GP"},{"Failures":18,"School":"MS"},{"Failures":1,"School":"GP"},{"Failures":3,"School":"GP"}], "A")
    [{'Failures': 1, 'School': 'GP'}, {'Failures': 3, 'School': 'GP'}, {'Failures': 11, 'School': 'GP'}, {'Failures': 18, 'School': 'MS'}]
    """

    if not any("Failures" in d for d in list_of_dict) == True:
        print(""""Failures" key is not present.""")
        return list_of_dict

    elif any("Failures" in d for d in list_of_dict) == True:
        # This goes into the list, and returns the values with the key "Failures" in a list, this is then sorted at the same time as the dictionary
        failure_list = [d["Failures"] for d in list_of_dict]

        swap = True
        while swap:
            swap = False
            for i in range(len(failure_list) - 1):
                if order == 'A':
                    if failure_list[i] > failure_list[i + 1]:
                        # swap the numbers in list with key of "Failures"
                        aux = failure_list[i]
                        failure_list[i] = failure_list[i + 1]
                        failure_list[i + 1] = aux

                        # swap dictionary based on numbers in list of key "Failures"
                        dict_pos_2 = list_of_dict[i]
                        list_of_dict[i] = list_of_dict[i + 1]
                        list_of_dict[i + 1] = dict_pos_2

                        swap = True
                elif order == 'D':
                    if failure_list[i] < failure_list[i + 1]:
                        # swap the numbers in list with key of "Failures"
                        aux = failure_list[i]
                        failure_list[i] = failure_list[i + 1]
                        failure_list[i + 1] = aux

                        # swap dictionary based on numbers in list of key "Failures"
                        dict_pos_2 = list_of_dict[i]
                        list_of_dict[i] = list_of_dict[i + 1]
                        list_of_dict[i + 1] = dict_pos_2
        return list_of_dict

#==========================================#
# Place your sort function after this line


def sort_by_key(dict_list: list[dict], asc_desc: str, attribute: str) -> list:
    """
    Given a list of dictionaries, whether to sort in ascending or descending order, and what attribute to sort by, returns a sorted list.

    Preconditions: asc_desc is either "A" or "D"

    Examples:
    >>>sort_by_key([{"Age":10,"School":"GP"},{"Age":19.1,"School":"MS"}],"D","Age")
    [{"Age": 19, "School":"MS"}, {"Age":10, "School":"GP"}]

    >>>sort_by_key([{"School":"GP"},{"School":"MS"}], "D", "School")
    Cannot be sorted by "School"
    [{"School":"GP"}, {"School":"MS"}]

    >>>sort_by_key([{'StudyTime': 3.5, 'Age': 15, 'Health': 3}, {'StudyTime': 1.5, 'Age': 18, 'Health': 5}, {'StudyTime': 2.0, 'Age': 17, 'Health': 4}], "A", "StudyTime")
    [{'StudyTime': 1.5, 'Age': 18, 'Health': 5}, {'StudyTime': 2.0, Age': 17, 'Health': 4}, {'StudyTime': 3.5, 'Age': 15, 'Health': 3}]
    """

    if attribute == "Age":
        return sort_students_age_bubble(dict_list, asc_desc)
    elif attribute == "StudyTime":
        return sort_students_time_selection(dict_list, asc_desc)
    elif attribute == "G_Avg":
        return sort_students_g_avg_insertion(dict_list, asc_desc)
    elif attribute == "Failures":
        return sort_students_failures_bubble(dict_list, asc_desc)
    else:
        print("Cannot be sorted by", attribute)
        return dict_list


# Do NOT include a main script in your submission
