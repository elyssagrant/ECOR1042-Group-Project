# ECOR 1042 Lab 3 - Team submission
# Remember to include docstring and type annotations for your functions

# Update "" to list all students contributing to the team work
import string
__author__ = "Elyssa Grant, Kaeler Howk, Lucas McDonald, Josh Elsasser"

# Update "" with your team (e.g. T102)
__team__ = "T-83"

#==========================================#
# Place your student_school_list function after this line


def student_school_list(file_name: str, school: str) -> list[dict[str]]:
    """The function takes the name of the file where the data is stored (data_file) and the name of a school.  The function returns a list of students (stored as a dictionary) that attended the given school.  If the name of the school provided is not in the data_file, the dunction returns an empty list.

    >>> student_school_list('student-mat.csv', 'GP')
    [ {'Age': 18, 'StudyTime': 2.0, 'Failures': 0, 'Health':  3, 'Absences': 6, 'G1': 5, 'G2': 6, 'G3': 6}, {another element},... , {'Age': 17, 'StudyTime': 1.0, 'Failures': 3, 'Health':  3, 'Absences': 2, 'G1': 9, 'G2': 8, 'G3': 10}]

    >>> student_school_list('student-mat.csv', 'BD')
    [ {'Age': 18, 'StudyTime': 2.0, 'Failures': 1, 'Health':  2, 'Absences': 0, 'G1': 7, 'G2': 7, 'G3': 0}, {another element},... , {'Age': 17, 'StudyTime': 3.0, 'Failures': 0, 'Health':  5, 'Absences': 0, 'G1': 11, 'G2': 11, 'G3': 10}]

    >>> student_school_list('student-mat.csv', 'CARLETON')
    []
    """

    infile = open(file_name, "r")  # opens the given file

    infile.readline()  # skips over the first line of the file

    school_data_list = []  # creates an empty list

    for line in infile:  # iterates through the file
        # creates a list for each line of data and removes comas.
        line = line.strip().split(",")

        # defines a dictionary that contains the school
        school_data = {'School': line[0]}

        if school in school_data.values():  # checks if the argument is a desired school

            # creates a dictionary containing data for: age, studytime, failures, health, absences, G1, G2, G3.
            data_of_school = {'Age': int(line[1]), 'StudyTime': float(line[2]), 'Failures': int(line[3]), 'Health': int(
                line[4]), 'Absences': int(line[5]), 'G1': int(line[6]), 'G2': int(line[7]), 'G3': int(line[8])}

            # appends the dictionary "data_of_school" to the list "school_data_list"
            school_data_list.append(data_of_school)

    infile.close()  # closes the given file

    # returns "school_data_list, which is a list containing dictionaries with the desired information.
    return school_data_list

    # Do NOT include a main script in your submission

#==========================================#
# Place your student_health_list function after this line


def student_health_list(datafile, healthiness: int) -> list:
    """
    Given the data sheet name and a value of how healthy the student is from 1 to 5, returns the files of all students with that level of health as a list of dictionaries, excluding the health value. If the health value is not in the file, returns an empty list

    Preconditions: data file named 'student-mat.csv'

    Examples:

    >>> student_health_list('student-mat.csv', 2)
    [ {'School': 'MS', 'Age': 20, 'StudyTime': 1.2, 'Failures': 1, 'Absences': 10,
     'G1': 9, 'G2': 11, 'G3': 7}, {another element}, … ]

     >>> student_health_list('student-mat.csv', -3)
     []

    """
    # importing modules
    import string

    # opening the file
    file = open(datafile, 'r')

    # creating a list of the keys for the dictionaries
    dictionary_keys = (file.readline()).strip().split(",")

    # Creating an empty list and dictionary
    all_relevant_students = []
    student = {}

    # looping over the entire file one line at a time
    for line in file.readlines():

        # Clearing line of whitespace and splitting the string into a list of individual words
        words = line.strip().split(",")

        # checking if the health value is equal to the specified value in order to get dictionary
        if int(words[4]) == healthiness:

            # looping over every piece of data to add it to the dictionary
            for i in range(len(words)):

                # changing the data to the appropriate value types
                if i != 0 and i != 2:
                    words[i] = int(words[i])

                elif i == 2:
                    words[i] = float(words[i])

                # adding the value to the temporary dictionary
                student[dictionary_keys[i]] = words[i]

            del student['Health']

            all_relevant_students.append(student.copy())

    file.close()

    return all_relevant_students

#==========================================#
# Place your student_age_list function after this line


def student_age_list(filename: str, age: int) -> dict:
    """ Returns the information of all students of a certain age, given the file
   with the data and the age specified

   Preconditions: 15 < age < 22. filename must be a string that calls the name of the file. The file must be a .csv file

   Examples:
   >>>student_age_list('student-mat.csv', 18)
   [{'School': 'GP', 'StudyTime': 2.0, 'Failures': 0, 'Health': 3, 'Absences': 6, 'G1': 5, 'G2': 6, 'G3': 6}, {'School': 'MB', 'StudyTime': 1.0, 'Failures': 2, 'Health': 4, 'Absences': 0, 'G1': 7, 'G2': 4, 'G3': 0}, ... {'School': 'MS', 'StudyTime': 1.0, 'Failures': 0, 'Health': 5, 'Absences': 0, 'G1': 11, 'G2': 12, 'G3': 10}]
   >>>student_age_list('student-mat.csv', 31)
   []

   """
    returnlist = []
    filedata = open(filename, "r")

    for line in filedata:
        words = line.split(",")
        words[-1] = words[-1].strip('\n')
        if words[1] == str(age):
            students = {}
            students['School'] = words[0]
            students['StudyTime'] = float(words[2])
            students['Failures'] = int(words[3])
            students['Health'] = int(words[4])
            students['Absences'] = int(words[5])
            students['G1'] = int(words[6])
            students['G2'] = int(words[7])
            students['G3'] = int(words[8])
            returnlist.append(students)
    filedata.close()
    return returnlist

#==========================================#
# Place your student_failures_list function after this line


def student_failures_list(file_name: str, failure_number: int) -> list:
    """  Returns list of students with the same amount of failures as the input parameter.  

    Precondition: file_name is of type string, file_name is name of file to be read and is of type csv
                  failure_number is of type int, failure_number >= 0

    >>> student_failures_list('student-mat.csv', 0)
    [ {'School': 'GP', 'Age': '18', 'StudyTime': '2', 'Health': '3', 'Absences': '6', 'G1': '5', 'G2': '6', 'H3': '6'},
    {another element},
    ... 
    ]

    >>> student_failures_list('student-mat.csv', 4)
    []

    >>> student_failures_list('student-mat.csv', 3)
    [{'School': 'GP', 'Age': 15, 'StudyTime': 2.0, 'Health': 3, 'Absences': 10, 'G1': 7, 'G2': 8, 'G3': 10}, {'School': 'GP', 'Age': 17, 'StudyTime': 1.0, 'Health': 5, 'Absences': 16, 'G1': 6, 'G2': 5, 'G3': 5}, {'School': 'GP', 'Age': 17, 'StudyTime': 1.0, 'Health': 3, 'Absences': 2, 'G1': 8, 'G2': 8, 'G3': 10}, {'School': 'MB', 'Age': 19, 'StudyTime': 2.0, 'Health': 5, 'Absences': 2, 'G1': 7, 'G2': 8, 'G3': 9}, {'School': 'MB', 'Age': 17, 'StudyTime': 1.0, 'Health': 5, 'Absences': 0, 'G1': 5, 'G2': 0, 'G3': 0}, {'School': 'MB', 'Age': 15, 'StudyTime': 2.0, 'Health': 3, 'Absences': 0, 'G1': 6, 'G2': 7, 'G3': 0}, {'School': 'MB', 'Age': 15, 'StudyTime': 1.0, 'Health': 5, 'Absences': 0, 'G1': 8, 'G2': 9, 'G3': 10}, {'School': 'MB', 'Age': 18, 'StudyTime': 1.0, 'Health': 4, 'Absences': 0, 'G1': 6, 'G2': 5, 'G3': 0}, {'School': 'MB', 'Age': 19, 'StudyTime': 1.0, 'Health': 4, 'Absences': 0, 'G1': 5, 'G2': 0, 'G3': 0}, {'School': 'MB', 'Age': 18, 'StudyTime': 1.0, 'Health': 4, 'Absences': 6, 'G1': 9, 'G2': 8, 'G3': 10}, {'School': 'CF', 'Age': 17, 'StudyTime': 2.0, 'Health': 5, 'Absences': 0, 'G1': 5, 'G2': 8, 'G3': 7}, {'School': 'CF', 'Age': 16, 'StudyTime': 2.0, 'Health': 3, 'Absences': 0, 'G1': 8, 'G2': 7, 'G3': 0}, {'School': 'CF', 'Age': 16, 'StudyTime': 2.0, 'Health': 4, 'Absences': 5, 'G1': 7, 'G2': 7, 'G3': 7}, {'School': 'BD', 'Age': 22, 'StudyTime': 1.0, 'Health': 1, 'Absences': 16, 'G1': 6, 'G2': 8, 'G3': 8}, {'School': 'MS', 'Age': 19, 'StudyTime': 2.0, 'Health': 2, 'Absences': 8, 'G1': 8, 'G2': 7, 'G3': 8}, {'School': 'MS', 'Age': 21, 'StudyTime': 1.0, 'Health': 3, 'Absences': 3, 'G1': 10, 'G2': 8, 'G3': 7}]

    """
    infile = open(file_name, 'r')

    fail_dict_of_failure_number = []

    infile.readline()  # Reads the first line of code which containes headers

    for line in infile:  # Goes through file line by line
        line = line.strip().split(",")  # splits each line into multiple segments

        data = {'School': line[0], 'Age': int(line[1]), 'StudyTime': float(line[2]), 'Health': int(line[4]), 'Absences': int(line[5]), 'G1': int(line[6]), 'G2': int(
            line[7]), 'G3': int(line[8])}  # defines dictionary with specific name and its value (which is associated with index number) *NOTE does not contain 'Failures'
        #data['Age'] = int(data['Age'])
        # Creates new dictionary with data of Failures and its value
        failure_data = {'Failures': line[3]}

        # searches failure_data for the input value
        if str(failure_number) in failure_data.values():
            # appends the list with the data if is true
            fail_dict_of_failure_number.append(data)

    infile.close()
    return fail_dict_of_failure_number


# Do NOT include a main script in your submission


#==========================================#
# Place your load_data function after this line

def load_data(file_name: str, data_type_value: tuple) -> list:
    """
    Given the name of the data file and a tuple containing the value type and value to be filtered, returns a list of all the students with the specified value, with the value type not included in the dictionary

    Precondition: file called is configured like student-mat.csv

    Examples:

    >>> load_data('student-mat.csv', ('Failures', 0))
    [ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7, 'Health': 3,
 n   'Absences': 7, 'G1': 12, 'G2': 13, 'G3': 14}, {another element}, … ] 

    >>> load_data('student-mat.csv', ('Jackpots', 4))
    'Invalid Value'
    []

    >>> load_data('student-mat.csv', ('Health', 2))
    [{'School': 'GP', 'Age': 15, 'StudyTime': 2.0, 'Failures': 0, 'Absences': 0, 'G1': 10, 'G2': 8, 'G3': 9}, {'School': 'GP', 'Age': 16, 'StudyTime': 1.0, 'Failures': 0, 'Absences': 4, 'G1': 14, 'G2': 14, 'G3': 14}, ... {'School': 'MS', 'Age': 17, 'StudyTime': 1.0, 'Failures': 0, 'Absences': 3, 'G1': 14, 'G2': 16, 'G3': 16}]

    """

    if data_type_value[0] == 'School':
        return student_school_list(file_name, data_type_value[1])

    elif data_type_value[0] == 'Health':
        return student_health_list(file_name, data_type_value[1])

    elif data_type_value[0] == 'Failures':
        return student_failures_list(file_name, data_type_value[1])

    elif data_type_value[0] == 'Age':
        return student_age_list(file_name, data_type_value[1])
    elif data_type_value[0] == 'All':

        returnlist = []
        filedata = open(file_name, "r")

        filedata.readline()

        for line in filedata:
            words = line.split(",")
            words[-1] = words[-1].strip('\n')

            students = {}
            students['School'] = words[0]
            students['Age'] = int(words[1])
            students['StudyTime'] = float(words[2])
            students['Failures'] = int(words[3])
            students['Health'] = int(words[4])
            students['Absences'] = int(words[5])
            students['G1'] = int(words[6])
            students['G2'] = int(words[7])
            students['G3'] = int(words[8])
            returnlist.append(students)
        filedata.close()

        return returnlist

    else:
        print('Invalid Value')
        return []

#==========================================#
# Place your add_average function after this line


def add_average(list_of_students: list) -> list:
    """
    Returns the average rounded to 2 decimal places of the students three grades, integers G1, G2, G3

    Precondition:  student_dict is of type list, all integer values are positive

add_average([ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7,
    'Failures': 1, 'Health': 3, 'Absences': 7,
    'G1': 5, 'G2': 6, 'G3': 6},
    {another element},
    … ] )
    [ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7, 'Failures': 1,
    'Health': 3, 'Absences': 7, 'G1': 5, 'G2': 6, 'G3': 6,
    'G_Avg': 5.67 },
    {another element},
    …
    ]

    >>> add_average([ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7,
    'Failures': 1, 'Health': 3, 'Absences': 7,
    'G1': 76, 'G2': 6, 'G3': 6},
    {another element},
    … ] )
    [ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7, 'Failures': 1,
    'Health': 3, 'Absences': 7, 'G1': 5, 'G2': 6, 'G3': 6,
    'G_Avg': 6 },
    {another element},
    …
    ]

    >>> add_average([ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7,
    'Failures': 1, 'Health': 3, 'Absences': 7,
    'G1': 5, 'G2': 6, 'G3': 6},
    {another element},
    … ] )
    [ {'School': 'GP', 'Age': 18, 'StudyTime': 6.7, 'Failures': 1,
    'Health': 3, 'Absences': 7, 'G1': 1, 'G2': 5, 'G3': 4,
    'G_Avg': 1.67 },
    {another element},
    …
    ]
    """

    for i in range(len(list_of_students)):

        list_of_students[i]['G_Avg'] = (
            list_of_students[i].get('G1') + list_of_students[i].get('G2') + list_of_students[i].get('G3')) / 3

        list_of_students[i]['G_Avg'] = round(list_of_students[i]['G_Avg'], 2)

    return list_of_students


# Do NOT include a main script in your submission
