# ECOR 1042 Lab 6 - Individual submission for text_UI

# Update "" with your name (e.g., Cristina Ruiz Martin)
__author__ = "Lucas McDonald"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101264037"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-83"

#==========================================#
# Place your script for your text_UI after this line
import load_data  # importing modules needed
import sort
import curve_fit
import histogram
is_data_loaded = 0  # check to see if data is loaded
withaverage = ''
v = 0
while v < 1:  # loop does not end until exit command is used
    command = ''
    # display commands and ask for input
    string = "The available commands are: \n L)oad data \n S)ort Data \n C)urve Fit \n H)istogram \n E)xit \n"
    command = input(string)
    if command == "L" or command == 'l':  # check to see what command is entered
        # ask for file name
        filename = input("Please enter the name of the file:")
        i = 0
        while i < 1:  # loop does not end until data is loaded
            attribute = input(
                "Please enter the attribute to use as a filter:")  # ask for attribute to filter
            if attribute == 'All':
                loaded_data = load_data.load_data(
                    filename, (attribute, -1))  # collects data from file
                withaverage = load_data.add_average(
                    loaded_data)  # adds the g_avg entry
                is_data_loaded = 1  # notes that the data is loaded
                break  # exits loop
            elif attribute == 'Age' or 'School' or 'Failures' or 'Health':
                attribute_value = input(
                    "Please enter the value of the attribute:")
                loaded_data = load_data.load_data(
                    filename, (attribute, attribute_value))
                withaverage = load_data.add_average(loaded_data)
                is_data_loaded = 1
                break
            else:
                # repeats loop if invalid attribute is entered
                print("Attribute invalid, please try again.")
    elif command == "S" or command == "s":  # sort command
        w = 0
        while w < 1:
            if is_data_loaded == 0:  # checks if the data is loaded, exits loop if not
                print("Data is not loaded. Please load data first")
                break
            print("Please enter the attribute you want to use for sorting:")
            # asks user for attribute to sort list by
            sorting_attribute = input(" Age, StudyTime, Failures, G_Avg:")
            # asks user for sorting order
            order = input("Ascending (A) or Descending (D) order:")
            if sorting_attribute not in withaverage[1].keys():
                print("Sorting attribute is not valid, please try again")
            elif sorting_attribute == 'Age':  # runs different function call depending on attribute
                sorted_data = sort.sort_students_age_bubble(
                    withaverage, order)
                question = input(
                    "Data Sorted. Do you want to display the data (Y or N)?")
                if question == 'Y':
                    print(sorted_data)
                break
            elif sorting_attribute == 'StudyTime':
                sorted_data = sort.sort_students_time_selection(
                    withaverage, order)
                question = input(
                    "Data Sorted. Do you want to display the data (Y or N)?")
                if question == 'Y':
                    print(sorted_data)
                break
            elif sorting_attribute == 'Failures':
                sorted_data = sort.sort_students_failures_bubble(
                    withaverage, order)
                question = input(
                    "Data Sorted. Do you want to display the data (Y or N)?")
                if question == 'Y':
                    print(sorted_data)
                break
            elif sorting_attribute == 'G_Avg':
                sorted_data = sort.sort_students_g_avg_insertion(
                    withaverage, order)
                question = input(
                    "Data Sorted. Do you want to display the data (Y or N)?")
                if question == 'Y':
                    print(sorted_data)
                break
            else:
                print("Sorting attribute is not valid, please try again")
    elif command == "C" or command == "c":
        t = 0
        while t < 1:
            if is_data_loaded == 0:
                print("Data is not loaded. Please load data first")
                break
            curve_attribute = input(
                "Please enter the attribute you want to use to find the best fit for G_Avg:")
            if curve_attribute == "Age" or "Failures" or "StudyTime" or "G_Avg" or "Health":
                curve_order = int(input(
                    "Please enter the order of the polynomial to be fitted:"))
                curve_equation = curve_fit.curve_fit(
                    withaverage, curve_attribute, curve_order)  # finding the curve equation with the curve_fit function
                print(curve_equation)
                break  # exits the loop
            else:
                print("Attribute is invalid, please try again")
    elif command == "H" or command == "h":
        z = 0
        while z < 1:
            if is_data_loaded == 0:
                print("Data is not loaded. Please load data first")
                break
            hist_attribute = input(
                "Please enter the attribute you want to use for plotting:")
            if hist_attribute == "Age" or "Failures" or "StudyTime" or "G_Avg" or "Health" or "School" or "G1" or "G2" or "G3":  # checks if the attribute is valid
                # calling the histogram function displays a histogram
                histogram.histogram(withaverage, hist_attribute)
                break
            else:
                print("Attribute is invalid, please try again")
    elif command == "E" or command == "e":
        # ends program if the E command is used
        break
    else:
        # restarts the UI if an invalid command is entered
        print("Invalid command, please try again")
