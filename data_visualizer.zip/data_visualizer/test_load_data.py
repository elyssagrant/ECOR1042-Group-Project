# ECOR 1042 Lab 4 - team submission

# import check module here
import check
# import load_data module here
import load_data

# Update "" with your the name of the active members of the team
__author__ = "Elyssa Grant, Kaeler Howk, Lucas McDonald, Josh Elsasser"

# Update "" with your student number (e.g., 100100100)

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-83"

#==========================================#

# Place test_return_list function here


def test_return_list():

    # Complete the function with your test cases

    #infile = open(load_data, 'r')

    # test that student_school_list returns a list (3 different test cases required)
    check.equal(type(load_data.student_school_list(
        'student-test.csv', 'GP')), list)
    check.equal(type(load_data.student_school_list(
        'student-test.csv', 'WB')), list)
    check.equal(type(load_data.student_school_list(
        'student-test.csv', 'MS')), list)

    # test that student_age_list returns a list (3 different test cases required)
    check.equal(type(load_data.student_age_list(
        'student-test.csv', '15')), list)
    check.equal(type(load_data.student_age_list(
        'student-test.csv', '16')), list)
    check.equal(type(load_data.student_age_list(
        'student-test.csv', '999')), list)

    # test that student_health_list returns a list (3 different test cases required)
    check.equal(type(load_data.student_health_list(
        'student-test.csv', 3)), list)
    check.equal(type(load_data.student_health_list(
        'student-test.csv', 5)), list)
    check.equal(type(load_data.student_health_list(
        'student-test.csv', 10238091)), list)

    # test that student_failures_list returns a list (3 different test cases required)
    check.equal(type(load_data.student_failures_list(
        'student-test.csv', 1)), list)
    check.equal(type(load_data.student_failures_list(
        'student-test.csv', 8137624821763)), list)
    check.equal(type(load_data.student_failures_list(
        'student-test.csv', 3)), list)

    # test that load_data returns a list (6 different test cases required)
    check.equal(type(load_data.load_data(
        'student-test.csv', ('School', 'GP'))), list)

    check.equal(type(load_data.load_data(
        'student-test.csv', ('Age', 18))), list)

    check.equal(type(load_data.load_data(
        'student-test.csv', ('Failures', 0))), list)

    check.equal(type(load_data.load_data(
        'student-test.csv', ('Health', 3))), list)

    check.equal(type(load_data.load_data(
        'student-test.csv', ('All', 2))), list)

    check.equal(type(load_data.load_data(
        'student-test.csv', ('aldfjoas', 2))), list)

    # test that add_average returns a list (3 different test cases required)

    check.equal(type(load_data.add_average([])), list)

    check.equal(type(load_data.add_average(([{'School': 'GP', 'Age': 18, 'StudyTime': 6.7, 'Failures': 0, 'Health': 4, 'Absences': 6, 'G1': 5, 'G2': 5, 'G3': 3}, {
                'School': 'GP', 'Age': 16, 'StudyTime': 6, 'Failures': 1, 'Health': 2, 'Absences': 3, 'G1': 5, 'G2': 1, 'G3': 5}]))), list)

    check.equal(type(load_data.add_average(([{'School': 'GP', 'Age': 18, 'StudyTime': 1, 'Failures': 0, 'Health': 4, 'Absences': 5, 'G1': 1, 'G2': 5, 'G3': 6}, {'School': 'SP', 'Age': 17, 'StudyTime': 6.7, 'Failures': 2, 'Health': 3, 'Absences': 4, 'G1': 2, 'G2': 5, 'G3': 3}, {
                'School': 'GP', 'Age': 16, 'StudyTime': 2, 'Failures': 4, 'Health': 4, 'Absences': 7, 'G1': 5, 'G2': 4, 'G3': 7}, {'School': 'S)', 'Age': 15, 'StudyTime': 3, 'Failures': 6, 'Health': 1, 'Absences': 6, 'G1': 6, 'G2': 3, 'G3': 3}]))), list)

    check.summary()


# Place test_return_list_correct_lenght function here
def test_return_list_correct_lenght():
    # Complete the function with your test cases

    # test that student_school_list returns a list with the correct lenght (3 different test cases required)

    check.equal(len(load_data.student_school_list(
        "student-test.csv", "Carleton")), 0)
    check.equal(len(load_data.student_school_list(
        "student-test.csv", "GP")), 3)
    check.equal(len(load_data.student_school_list(
        "student-test.csv", "MB")), 2)

    # test that student_age_list returns a list  with the correct lenght (3 different test cases required)

    check.equal(len(load_data.student_age_list("student-test.csv", 30)), 0)
    check.equal(len(load_data.student_age_list("student-test.csv", 15)), 3)
    check.equal(len(load_data.student_age_list("student-test.csv", 17)), 6)
    # test that student_health_list returns a list  with the correct lenght (3 different test cases required)

    check.equal(len(load_data.student_health_list(
        "student-test.csv", 100)), 0)
    check.equal(len(load_data.student_health_list("student-test.csv", 1)), 1)
    check.equal(len(load_data.student_health_list("student-test.csv", 5)), 3)

    # test that student_failures_list returns a list   with the correct lenght(3 different test cases required)

    check.equal(
        len(load_data.student_failures_list("student-test.csv", 10)), 0)
    check.equal(
        len(load_data.student_failures_list("student-test.csv", 0)), 11)
    check.equal(
        len(load_data.student_failures_list("student-test.csv", 2)), 2)

    # test that load_data returns a list  with the correct lenght (6 different test cases required)

    check.equal(len(load_data.load_data(
        "student-test.csv", ('School', 'CF'))), 3)
    check.equal(len(load_data.load_data(
        "student-test.csv", ('Failures', 3))), 1)
    check.equal(len(load_data.load_data("student-test.csv", ('Age', 18))), 4)
    check.equal(len(load_data.load_data(
        "student-test.csv", ('Health', 4))), 3)
    check.equal(len(load_data.load_data("student-test.csv", ('All', 0))), 15)
    check.equal(len(load_data.load_data(
        "student-test.csv", ('Greg', 12))), 0)

    # test that add_average returns a list   with the correct lenght (3 different test cases required)

    check.equal(len(load_data.add_average([])), 0)
    check.equal(len(load_data.add_average([{'Age': 16, 'StudyTime': 2.0, 'Failures': 0, 'Health': 3, 'Absences': 12, 'G1': 5, 'G2': 5, 'G3': 5}, {
                'Age': 15, 'StudyTime': 1.0, 'Failures': 0, 'Health': 3, 'Absences': 2, 'G1': 10, 'G2': 12, 'G3': 12}])), 2)
    check.equal(len(load_data.add_average([{'School': 'MS', 'Age': 17, 'StudyTime': 3.0,
                'Failures': 0, 'Absences': 7, 'G1': 10, 'G2': 9, 'G3': 9}])), 1)

    check.summary()

# Place test_return_correct_dict_inside_list function here


def test_return_correct_dict_inside_list():
    # Complete the function with your test cases

    # test that student_school_list returns a correct dictionary inside the list (3 different test cases required)

    check.equal(list(load_data.student_school_list(                             # Tests the dict for the correct keys
        'student-test.csv', 'GP')[0].keys()), (['Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_school_list(                             # Tests the dict for the correct values and types
        'student-test.csv', 'GP')[0].values()), [18, 2.0, 0, 3, 6, 5, 6, 6])

    check.equal(list(load_data.student_school_list(
        'student-test.csv', 'MS')[-1].keys()), (['Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_school_list(
        'student-test.csv', 'MS')[-1].values()), [18, 3.0, 0, 5, 2, 9, 8, 8])

    check.equal(list(load_data.student_school_list(
        'student-test.csv', 'CF')[1].keys()), (['Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_school_list(
        'student-test.csv', 'CF')[1].values()), [16, 2.0, 1, 5, 4, 10, 12, 12])

    # test that student_age_list returns a correct dictionary inside the list  (3 different test cases required)

    check.equal(list(load_data.student_age_list(
        'student-test.csv', 18)[0].keys()), (['School', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_age_list(
        'student-test.csv', 18)[0].values()), ['GP', 2.0, 0, 3, 6, 5, 6, 6])

    check.equal(list(load_data.student_age_list(
        'student-test.csv', 18)[-1].keys()), (['School', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_age_list(
        'student-test.csv', 18)[-1].values()), ['MS', 3.0, 0, 5, 2, 9, 8, 8])

    check.equal(list(load_data.student_age_list(
        'student-test.csv', 15)[2].keys()), (['School', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_age_list(
        'student-test.csv', 15)[2].values()), ['CF', 5.0, 2, 3, 6, 5, 9, 7])

    # test that student_health_list returns a correct dictionary inside the list  (3 different test cases required)

    check.equal(list(load_data.student_health_list(
        'student-test.csv', 3)[0].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_health_list(
        'student-test.csv', 3)[0].values()), ['GP', 18, 2.0, 0, 6, 5, 6, 6])

    check.equal(list(load_data.student_health_list(
        'student-test.csv', 5)[-1].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_health_list(
        'student-test.csv', 5)[-1].values()), ['MS', 18, 3.0, 0, 2, 9, 8, 8])

    check.equal(list(load_data.student_health_list(
        'student-test.csv', 1)[0].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_health_list(
        'student-test.csv', 1)[0].values()), ['MS', 17, 3.0, 0, 7, 10, 9, 9])

    # test that student_failures_list returns a correct dictionary inside the list (3 different test cases required)

    check.equal(list(load_data.student_failures_list(
        'student-test.csv', 0)[0].keys()), (['School', 'Age', 'StudyTime', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_failures_list(
        'student-test.csv', 0)[0].values()), ['GP', 18, 2.0, 3, 6, 5, 6, 6])

    check.equal(list(load_data.student_failures_list(
        'student-test.csv', 0)[-1].keys()), (['School', 'Age', 'StudyTime', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_failures_list(
        'student-test.csv', 0)[-1].values()), ['MS', 18, 3.0, 5, 2, 9, 8, 8])

    check.equal(list(load_data.student_failures_list(
        'student-test.csv', 2)[0].keys()), (['School', 'Age', 'StudyTime', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.student_failures_list(
        'student-test.csv', 2)[0].values()), ['CF', 15, 5.0, 3, 6, 5, 9, 7])

    # test that load_data returns a correct dictionary inside the list (6 different test cases required)

    check.equal(list(load_data.load_data(
        'student-test.csv', ('All', 0))[0].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.load_data(
        'student-test.csv', ('All', 0))[0].values()), ['GP', 18, 2.0, 0, 3, 6, 5, 6, 6])

    check.equal(list(load_data.load_data(
        'student-test.csv', ('Age', 18))[0].keys()), (['School', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.load_data(
        'student-test.csv', ('Age', 18))[0].values()), ['GP', 2.0, 0, 3, 6, 5, 6, 6])

    check.equal(list(load_data.load_data(
        'student-test.csv', ('School', 'GP'))[0].keys()), (['Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.load_data(
        'student-test.csv', ('School', 'GP'))[0].values()), [18, 2.0, 0, 3, 6, 5, 6, 6])

    check.equal(list(load_data.load_data(
        'student-test.csv', ('Health', 3))[0].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.load_data(
        'student-test.csv', ('Health', 3))[0].values()), ['GP', 18, 2.0, 0, 6, 5, 6, 6])

    check.equal(list(load_data.load_data(
        'student-test.csv', ('Failures', 0))[0].keys()), (['School', 'Age', 'StudyTime', 'Health', 'Absences', 'G1', 'G2', 'G3']))
    check.equal(list(load_data.load_data(
        'student-test.csv', ('Failures', 0))[0].values()), ['GP', 18, 2.0, 3, 6, 5, 6, 6])

    check.equal(load_data.load_data(
        'student-test.csv', ('Age', 0)), [])

    # test that add_average returns a lcorrect dictionary inside the list  (3 different test cases required)
    check.equal(list(load_data.add_average(list(load_data.load_data('student-test.csv', ('All', 0))))
                     [0].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3', 'G_avg']))
    check.equal(list(load_data.add_average(load_data.load_data(
        'student-test.csv', ('All', 0)))[0].values()), ['GP', 18, 2.0, 0, 3, 6, 5, 6, 6, 5.67])

    check.equal(list(load_data.add_average(list(load_data.load_data('student-test.csv', ('All', 0))))
                     [-1].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3', 'G_avg']))
    check.equal(list(load_data.add_average(load_data.load_data(
        'student-test.csv', ('All', 0)))[-1].values()), ['MS', 18, 3.0, 0, 5, 2, 9, 8, 8, 8.33])

    check.equal(list(load_data.add_average(list(load_data.load_data('student-test.csv', ('All', 0))))
                     [5].keys()), (['School', 'Age', 'StudyTime', 'Failures', 'Health', 'Absences', 'G1', 'G2', 'G3', 'G_avg']))
    check.equal(list(load_data.add_average(load_data.load_data(
        'student-test.csv', ('All', 0)))[5].values()), ['CF', 15, 5.0, 2, 3, 6, 5, 9, 7, 7.00])

    check.summary()

# Place test_add_average function here


def test_add_average():
    # Complete the function with your test cases

    # test that the function does not change the lengh of the list provided as input parameter (5 different test cases required)
    check.equal(len(load_data.add_average(load_data.load_data("student-test.csv",
                ('All', 3)))), len(load_data.load_data("student-test.csv", ("All", 3))))

    check.equal(len(load_data.add_average(load_data.load_data("student-test.csv",
                ('Health', 1)))), len(load_data.load_data("student-test.csv", ("Health", 1))))

    check.equal(len(load_data.add_average(load_data.student_age_list(
        "student-test.csv", 16))), len(load_data.student_age_list("student-test.csv", 16)))

    check.equal(len(load_data.add_average(load_data.student_school_list("student-test.csv", "GP"))),
                len(load_data.student_school_list("student-test.csv", "GP")), "test failed")

    check.equal(len(load_data.add_average(load_data.student_failures_list(
        "student-test.csv", 1))), len(load_data.student_failures_list("student-test.csv", 1)))

    # test that the function returns an empty list when it is called whith an empty list
    check.equal(load_data.add_average([]), [])

    # test that the function inscrememnts the number of keys of the dictionary inside the list by one  (5 different test cases required)

    check.equal(len(load_data.add_average(
        load_data.student_school_list("student-test.csv", "CF"))[1]), (len(
            load_data.student_school_list('student-test.csv', "CF")[1]) + 1))

    check.equal(len(load_data.add_average(
        load_data.student_age_list("student-test.csv", 18))[-1]), (len(
            load_data.student_age_list('student-test.csv', 18)[-1]) + 1))

    check.equal(len(load_data.add_average(
        load_data.student_health_list("student-test.csv", 3))[-5]), (len(
            load_data.student_health_list('student-test.csv', 3)[-5]) + 1))

    check.equal(len(load_data.add_average(
        load_data.student_failures_list("student-test.csv", 1))[0]), (len(
            load_data.student_failures_list('student-test.csv', 1)[0]) + 1))

    check.equal(len(load_data.add_average(
        load_data.load_data("student-test.csv", ("All", -3)))[0]), (len(
            load_data.load_data('student-test.csv', ("All", -3))[0]) + 1))

    # test that the G_Avg value is properly calculated  (5 different test cases required)

    check.within(load_data.add_average(
        load_data.load_data("student-test.csv", ("All", 1)))[0]["G_Avg"], (load_data.load_data("student-test.csv", ("All", 1))[0]["G1"] + load_data.load_data("student-test.csv", ("All", 1))[0]["G2"] + load_data.load_data("student-test.csv", ("All", 1))[0]["G3"]) / 3, 0.01)

    check.within(load_data.add_average(
        load_data.load_data("student-test.csv", ("Health", 1)))[-1]["G_Avg"], (load_data.load_data("student-test.csv", ("Health", 1))[-1]["G1"] + load_data.load_data("student-test.csv", ("Health", 1))[-1]["G2"] + load_data.load_data("student-test.csv", ("Health", 1))[-1]["G3"]) / 3, 0.01)

    check.within(load_data.add_average(
        load_data.load_data("student-test.csv", ("Age", 15)))[2]["G_Avg"], (load_data.load_data("student-test.csv", ("Age", 15))[2]["G1"] + load_data.load_data("student-test.csv", ("Age", 15))[2]["G2"] + load_data.load_data("student-test.csv", ("Age", 15))[2]["G3"]) / 3, 0.01)

    check.within(load_data.add_average(
        load_data.load_data("student-test.csv", ("School", "MS")))[0]["G_Avg"], (load_data.load_data("student-test.csv", ("School", "MS"))[0]["G1"] + load_data.load_data("student-test.csv", ("School", "MS"))[0]["G2"] + load_data.load_data("student-test.csv", ("School", "MS"))[0]["G3"]) / 3, 0.01)

    check.within(load_data.add_average(
        load_data.load_data("student-test.csv", ("Failures", 0)))[-1]["G_Avg"], (load_data.load_data("student-test.csv", ("Failures", 0))[-1]["G1"] + load_data.load_data("student-test.csv", ("Failures", 0))[-1]["G2"] + load_data.load_data("student-test.csv", ("Failures", 0))[-1]["G3"]) / 3, 0.01)

    check.summary()


# Do NOT include a main script in your submission
