# ECOR 1042 Lab 6 - Individual submission for histogram

# Remember to include docstring and type annotations for your functions

# Update "" with your name (e.g., Cristina Ruiz Martin)
__author__ = "Kaeler Howk"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101255773"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-83"

#==========================================#
# Place your histogram function after this line


def histogram(list_of_dict: list[dict], attribute: str) -> None:
    """ Function creates Histogram of the values assoceated in the string(attribute) which is a key in the first peramater list_of_dict: list[dict],

    Preconditions: 
    list_of_dict is a list containing dictionaries 
    attribute is string and is key in all dictionaries listed

    >>> histogram([{"Failures":11,"School":"GP"},{"Failures":18,"School":"MS"},{"Failures":1,"School":"GP"},{"Failures":3,"School":"GP"}], "Failures")
    None #Bar graph(That looks like histogram) showing values: 11,18,1,3 titled 'Failures'

    >>> histogram([{"G_Avg":1.1,"Other":"GP"},{"G_Avg":1.8,"Other2":"MS"},{"G_Avg":0.1,"other3":"GP"},{"G_Avg":3.0,"Other4":"GP"}], "G_Avg")
    None #Graph showing values 1.1, 1.8, 0.1, 3.0 titled G_Avg

    >>> histogram([{"Health":1,"Other":"GP"},{"Health":8,"Other2":"MS"},{"Health":1,"other3":"GP"},{"Health":3,"Other4":"GP"}], "G_Avg")
    None #Graph showing values 1, 8, 1, 3 titled G_Avg
    """
    import matplotlib.pyplot as plt

    value_list = []
    for i in list_of_dict:  # Accesses the list containing dict
        value_list += [i.get(attribute, None)]
    values = value_list

    bin_size = 1

    if isinstance(values[0], float):
        if bin_size is None:
            bin_size = 0.1
        bins = [
            i * bin_size for i in range(int(min(values) / bin_size), int(max(values) / bin_size) + 2)]
    else:
        if bin_size is None:
            bin_size = 1
        bins = range(int(min(values) / bin_size) * bin_size,
                     int(max(values) / bin_size) + bin_size, bin_size)

    # Create a dictionary to store the count of each bin
    counts = {bin_value: 0 for bin_value in bins}
    for value in values:
        for bin_value in bins:
            if value >= bin_value and value < bin_value + bin_size:
                counts[bin_value] += 1
                break

    # Create a bar graph of the counts/values
    plt.bar(counts.keys(), counts.values(), align='edge', width=bin_size)

    plt.xticks(bins)
    plt.title(f"Histogram of {attribute}")
    plt.xlabel(attribute)
    plt.ylabel("Count")
    plt.show()

    return None

# Do NOT include a main script in your submission
